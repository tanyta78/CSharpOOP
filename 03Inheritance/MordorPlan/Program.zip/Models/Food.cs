﻿
   public abstract class Food
   {
        public abstract string getName();
        public abstract int getPointOfHappiness();
   }


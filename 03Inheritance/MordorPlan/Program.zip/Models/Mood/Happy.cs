﻿
   public class Happy:Mood
    {
    }


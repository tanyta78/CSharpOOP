﻿
   public class JavaScript:Mood
    {
    }


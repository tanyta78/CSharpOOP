﻿
   public class Sad:Mood
    {
    }


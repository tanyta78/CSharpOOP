﻿
   public class Angry:Mood
    {
    }


﻿using System.Collections.Generic;
using System.Text;

public class EarthNation : Nation
{
    private List<EarthBender> benders;
    private List<EarthMonument> monuments;
    private double totalPower;

    public EarthNation() : base()
    {
        this.benders = new List<EarthBender>();
        this.monuments = new List<EarthMonument>();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PawInc.Models.Centers
{
    public class CastrationCenter : Center
    {
        public CastrationCenter(string name) : base(name)
        {
        }
    }
}
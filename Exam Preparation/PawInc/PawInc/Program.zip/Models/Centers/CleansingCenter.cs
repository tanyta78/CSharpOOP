﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PawInc.Models.Centers
{
    public class CleansingCenter : Center
    {
        public CleansingCenter(string name) : base(name)
        {
        }
    }
}
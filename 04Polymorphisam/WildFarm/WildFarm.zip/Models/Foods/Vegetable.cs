﻿
   public class Vegetable:Food
    {
        public Vegetable(int quantity)
        {
            this.Quantity = quantity;
        }
}


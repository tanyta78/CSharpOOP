﻿public class Program
{
    private static void Main()
    {
        var engine = new Engine();
        engine.Start();
    }
}